﻿class szamla_osztaly
{
    static void Main(string[] args)
    {
    }
}
