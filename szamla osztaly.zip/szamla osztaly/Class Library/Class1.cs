﻿namespace Class_Library
{
    public class Class1
    {

    }
}